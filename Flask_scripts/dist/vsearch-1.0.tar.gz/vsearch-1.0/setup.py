from setuptools import setup
setup(
name='vsearch',
version='1.0',
description='The Head First Python Search Tools',
author='Asya Chirchenko',
author_email='pendofiliya26@gmail.com',
url='#',
py_modules=['vsearch'],)